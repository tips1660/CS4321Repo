package logicalOperators;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import project2DB.*;

/**
 * PhysicalPlanBuilder constructs the physical operators from the logical plan by visiting the root operator and its successive children
 * @author Pulkit Kashyap pk374 Robert Cao rrc85 Jason Zhou jz629
 */

public class PhysicalPlanBuilder {

	Operator root;
	Operator current;

	int joinType;
	int joinBuffer;
	String tempDir;
	int sortType;
	int sortBuffer;

	int useIndexes;
	IndexVisitor visitor = new IndexVisitor();
	boolean isPrevSel = false;
	private BufferedWriter logicWriter;
	int ctr=0;


	public PhysicalPlanBuilder(int j1, int j2, int s1, int s2, int u) {
		joinType = j1;
		joinBuffer = j2;
		sortType = s1;
		sortBuffer = s2;
		useIndexes = u;
	}

	/**
	 * Sets a new temp directory
	 * @param temp
	 */
	public void setTempDir(String temp)
	{
		tempDir = temp;
	}

	/**
	 * Gets the root of the builder
	 * @return root
	 */
	public Operator getRoot()
	{
		return root;
	}

	/**
	 * Resets the builder for new queries
	 */
	public void reset()
	{
		root = null;
		current = null;
	}

	/**
	 * Method for visiting a ScanOperatorLogical 
	 * @param s
	 * @throws IOException
	 */
	public void visit(ScanOperatorLogical s) throws IOException
	{
		if(isPrevSel){
			ctr++;

		}

		StringBuilder upcomingString = new StringBuilder();

		for(int i =0; i<ctr; i++)
		{
			upcomingString.append("-");
		}

		upcomingString.append("LEAF["+ s.tableN.getWholeTableName()+"]");
		logicWriter.write(upcomingString.toString()+System.getProperty("line.separator"));
		if(isPrevSel){
			ctr--;
			isPrevSel = false;
		}
		if(root == null)
		{
			root = new scanOperator(s.tableN);
			current = root;

		}
		else{
			scanOperator nextOp = new scanOperator(s.tableN);
			//System.out.println(s.tableN.toString());
			current.setChild(nextOp);
			current = nextOp;

			System.out.println("PPB: I am here in my scan");
			if(s.child!=null) {
				System.out.println("PPB: Accepting scan");
				s.child.accept(this);
			}
		}
	}

	/**
	 * Method for visiting a ProjectOperatorLogical
	 * @param s
	 * @throws IOException
	 */
	public void visit(ProjectOperatorLogical s) throws IOException
	{
		if(s.items !=null)
		{
			StringBuilder upcomingString = new StringBuilder();
			for(int i =0; i<ctr; i++)
			{
				upcomingString.append("-");
			}

			upcomingString.append("Project"+s.items.toString());
			logicWriter.write(upcomingString.toString()+System.getProperty("line.separator"));
			ctr++;
		}
		System.out.println("PPB: I am at the project operator");
		if(root == null)
		{
			root = new ProjectOperator(s.out, s.items, s.joinList, s.tableN);
			current = root;
			if(s.child !=null)
				s.child.accept(this);

		}
		else
		{
			ProjectOperator nextOp = new ProjectOperator(s.items, s.joinList,  s.tableN);
			current.setChild(nextOp);
			current = nextOp;
			if(s.child!=null)
				s.child.accept(this);
		}
	}


	/**
	 * Method for visiting a DistinctOperatorLogical 
	 * @param s
	 * @throws IOException
	 */
	public void visit(DistinctOperatorLogical s) throws IOException{
		logicWriter.write("DupElim"+System.getProperty("line.separator"));
		ctr++;
		System.out.println("PPB: I got to distinct operator log");
		if(root == null)
		{
			root = new DuplicateEliminationOperator(s.out,s.items1,sortType,sortBuffer);
			current = root;
			if(s.child!=null)
				s.child.accept(this);

		}
		else
		{
			DuplicateEliminationOperator nextOp = new DuplicateEliminationOperator(s.out,s.items1,sortType,sortBuffer);
			current.setChild(nextOp);
			current = nextOp;
			if(s.child !=null)
				s.child.accept(this);
		}

	}

	/**
	 * Method for visiting a SortOperatorLogical 
	 * @param s
	 * @throws IOException
	 */
	public void visit(SortOperatorLogical s) throws IOException
	{  
		StringBuilder upcomingString = new StringBuilder();
		for(int i =0; i<ctr; i++)
		{
			upcomingString.append("-");
		}
 
		String name = (s.orderList!=null) ? s.orderList.toString() : "[*]"; 
		
		upcomingString.append("Sort"+name);
		logicWriter.write(upcomingString.toString()+System.getProperty("line.separator"));
		ctr++;
		
		if(root == null)
		{
			//System.out.println("Creating sortoperator");
			if (sortType == 0)
				root = new SortOperator(s.out, s.items1,  s.orderList);
			else {
				root = new ExternalSortOperator(s.out, s.tempdir, sortBuffer, s.querynum, s.items1, s.orderList);
			}
			current = root;
			if(s.child!=null)
				s.child.accept(this);
		}
		else
		{
			Operator nextOp;
			if (sortType == 0)
				nextOp = new SortOperator(s.items1,  s.orderList);
			else
				nextOp = new ExternalSortOperator(s.out, s.tempdir, sortBuffer, s.querynum, s.items1, s.orderList);
			current.setChild(nextOp);
			current = nextOp;
			if(s.child!=null)
			{
				//System.out.println(s.child.toString());
				s.child.accept(this);
			}
		}
	}

	/**
	 * Method for visiting a JoinOperatorLogical 
	 * @param s
	 * @throws IOException
	 */
	public void visit(JoinOperatorLogical s) throws IOException {
		StringBuilder upcomingString = new StringBuilder();
		for(int i =0; i<ctr; i++)
		{
			upcomingString.append("-");
		}

		upcomingString.append("Join"+s.getUnionFind().getRejectedExp().toString());
		logicWriter.write(upcomingString.toString()+System.getProperty("line.separator"));
		logicWriter.write(s.getUnionFind().toString());

		ctr++;


		JoinOperatorSuper nextOp = new JoinOperatorSuper(tempDir, s.tableN, s.jList, s.e, joinType, joinBuffer, sortType, sortBuffer, useIndexes);


		current.setChild(nextOp);
		current = nextOp;
		if(s.child!=null){
			//System.out.println("not null");
			s.child.accept(this);}
		System.out.println("PPB: Built my JoinOperatorSuper");

	}

	/**
	 * Method for visiting a SelectOperatorLogical 
	 * @param s
	 * @throws IOException
	 */
	public void visit(SelectOperatorLogical s) throws IOException {

		System.out.println("PPB: Select Operator Logical visited");
		StringBuilder upcomingString = new StringBuilder();
		for(int i =0; i<ctr; i++)
		{
			upcomingString.append("-");
		}

		upcomingString.append("Select["+s.getInput() + "]" + System.getProperty("line.separator"));
		logicWriter.write(upcomingString.toString());
		isPrevSel = true;

		String optimal = SelectOptimizer.chooseIndex(s.getTableN().getWholeTableName(),s.getInput());

		//We using indexes!!
		if (optimal != null){
			System.out.println("Optimizer using index");
			String a = optimal.split("\\.")[1];

			String index = visitor.setIndex(s.getTableN().getWholeTableName(),a);	//changed for 3.3
			s.input.accept(visitor);
			visitor.buildExpressions();
			boolean newChild = false;
			boolean fullIndex = false;

			IndexScanOperatorLogical childOp = null;
			Operator nextOp = null;
			if (!visitor.getIndexArray().isEmpty()) {
				//System.out.println("there exists a helpful index in select");
				newChild = true; 

				int cluster = visitor.setCluster(index,s.getTableN().getSchemaName());	//changed for 3.3
				File f = visitor.getFile();
				childOp = new IndexScanOperatorLogical();
				childOp.setHigh(visitor.getHigh());
				childOp.setLow(visitor.getLow());
				childOp.setTableN(s.getTableN());
				childOp.setCluster(cluster);
				childOp.setAttr(index);
				childOp.setFile(f);
				System.out.println("PPB: properly set indexscan child");
				if (visitor.getNotIndexExpression() != null) {
					s.setInput(visitor.getNotIndexExpression());
					System.out.println("PPB: the new select exp is "+s.getInput());
				}
				else {
					//there is no select condition, scan will handle all
					//nextOp will just be a indexscan with no child
					System.out.println("PPB: about to create indexscan as nextop");
					fullIndex = true;
					newChild = false;
					nextOp = new IndexScanOperator(s.getTableN(), f, index, cluster, visitor.getLow(), visitor.getHigh());
				}
			}
			//System.out.println("made indexscanoperator");
			visitor.reset();
			if (!fullIndex)
				nextOp = new SelectOperator(s.tableN, s.input);
			current.setChild(nextOp);
			current = nextOp;
			if (newChild) {
				s.setChild(childOp);
			}
		}
		else {
			SelectOperator nextOp = new SelectOperator(s.tableN, s.input);
			current.setChild(nextOp);
			current = nextOp;
		}

		if(s.getChild()!=null) {
			s.child.accept(this);
		}
	}

	/**
	 * Method for visiting an IndexScanOperatorLogical 
	 * @param s
	 * @throws IOException
	 */
	public void visit(IndexScanOperatorLogical s) throws IOException {

		IndexScanOperator nextOp = new IndexScanOperator(s.getTableN(), s.getFile(), s.getAttr(), s.getCluster(), s.getLow(), s.getHigh());
		current.setChild(nextOp);
		current = nextOp;

		if(s.child!=null) {
			s.child.accept(this);
		}
	}

	public void setBuffWriter(BufferedWriter logicWriter) {
		this.logicWriter = logicWriter;
		ctr = 0;
	}
}

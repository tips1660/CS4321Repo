package logicalOperators;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.select.Join;
import net.sf.jsqlparser.statement.select.OrderByElement;
import net.sf.jsqlparser.statement.select.SelectItem;

/**
 * DistinctOperatorLogical stores all the information needed to create a physical DistinctOperator in the PhysicalPlanBuilder
 * @author Pulkit Kashyap pk374 Robert Cao rrc85 Jason Zhou jz629
 */
public class DistinctOperatorLogical extends LogicalOperator {
   
	String out;
	
	/**
	 * Returns the name of the file to be written to
	 * @return out
	 */
	public String getOut() {
		return out;
	}

	/**
	 * Sets the name of the file to be written to
	 * @param out
	 */
	public void setOut(String out) {
		this.out = out;
	}


	/**
	 * Returns the selectitems
	 * @return items1
	 */
	public ArrayList<SelectItem> getItems1() {
		return items1;
	}

	/**
	 * Sets the selectitems
	 * @param items1
	 */
	public void setItems1(ArrayList<SelectItem> items1) {
		this.items1 = items1;
	}

	/**
	 * Returns the joinList 
	 * @return joinList
	 */
	public List<Join> getJoinList() {
		return joinList;
	}

	/**
	 * Sets the joinList
	 * @param joinList
	 */
	public void setJoinList(List<Join> joinList) {
		this.joinList = joinList;
	}

	/**
	 * Returns the select expression of the query
	 * @return select
	 */
	public Expression getSelect() {
		return select;
	}

	/**
	 * Sets the select expression of the query
	 * @param select
	 */
	public void setSelect(Expression select) {
		this.select = select;
	}

	/**
	 * Gets the table of the base relation
	 * @return tableN
	 */
	public Table getTableN() {
		return tableN;
	}

	/**
	 * Sets the table of the base relation
	 * @param tableN
	 */
	public void setTableN(Table tableN) {
		this.tableN = tableN;
	}

	/**
	 * Gets the order by list 
	 * @return orderList
	 */
	public List<OrderByElement> getOrderList() {
		return orderList;
	}

	/**
	 * Sets the order by list
	 * @param orderList
	 */
	public void setOrderList(List<OrderByElement> orderList) {
		this.orderList = orderList;
	}


	ArrayList<SelectItem> items1;
	List<Join> joinList;
	Expression select;
	Table tableN;
	List<OrderByElement> orderList;
	
	/**
	 * Sets the child of this operator
	 * @param t
	 */
	public void setChild(LogicalOperator t)
	{
		child = t;
	}
	
	/**
	 * Gets the child of this operator
	 * @return child
	 */
	public LogicalOperator getChild()
	{
		return child;
	}
	
	/**
	 * Method for visiting this operator in a physical plan builder
	 * @param s
	 */
	@Override
	public void accept(PhysicalPlanBuilder s) throws IOException
	{
		s.visit(this);
	}

}

package project2DB;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import net.sf.jsqlparser.schema.Table;
/**
 * IndexScanOperator is the class representing the index scan operator.
 * @author Robert Cao rrc8 Pulkit Kashyap pk374 Jason Zhou jz629
 */
public class IndexScanOperator extends Operator {

	public String table = "";
	String alias;
	private DatabaseCatalog dbcat = DatabaseCatalog.getInstance();
	String fileUrl = "";
	Tuple returnedTuple;
	tableProperties tableR;
	int tableCtr;
	int finalValue;
	File f;
	ArrayList<Integer> tuples;


	int cluster;
	Integer lowkey = null;
	Integer highkey = null;
	File indexFile = null;
	TupleReader reader;
	TreeDeserializer td;
	String attr;
	RId first = null;

	/**
	 * 
	 * @param relation the name of the relation you want to scan 
	 * @param indexFile the index file of the relation that you want to use
	 * @param attr	the name of the attribute the relation is indexed by
	 * @param cluster	1 for clustered index,  0 for unclustered index
	 * @param low	lowkey, null if not needed
	 * @param high	highkey, null if not needed
	 * @throws IOException
	 */
	public IndexScanOperator(Table relation, File indexFile, String attr, int cluster,Integer low, Integer high) throws IOException{
		System.out.println("Entering IndexScanOperator constructor");
		alias = relation.getAlias();
		table = relation.getWholeTableName();
		tableR = (tableProperties) dbcat.getTableCatalog().get(table);
		fileUrl = tableR.getUrl();
		tuples = new ArrayList<Integer>();


		this.indexFile = indexFile;
		this.cluster = cluster;
		this.attr = attr;
		lowkey = low;
		highkey = (high == -1) ? Integer.MAX_VALUE : high;
		
		td = new TreeDeserializer(indexFile,lowkey,high);


		//Set the reader based on existence of lowkey
		if (lowkey == -1){
			try {
				reader = new TupleReader(fileUrl);
			}
			catch (IOException e)
			{
				//System.out.println("Could not create a new indexscanOperator");
				e.printStackTrace();
			}
		}
		else{

		}

		if(this.cluster == 1)
		{
			RId RIDNext = td.getNextRId();
			first = RIDNext;
			reader = new TupleReader(fileUrl, RIDNext.getPageId(), RIDNext.getTupleId());
		}


		f = new File(fileUrl);
	}




	/**
	 * Gets the next tuple from this operator
	 * @return returnedTuple
	 */
	@Override
	public Tuple getNextTuple(){

		////System.out.println("xd");
		//unclustered implementation
		if (cluster == 0){
			RId RIdNext = null;
			try {
				RIdNext = td.getNextRId();
			} catch (IOException e) {
				e.printStackTrace();
			}

			if (RIdNext == null){
				Tuple returnedTuple = new Tuple(table, alias, reader);
				returnedTuple.setName("ENDOFFILE");
				return returnedTuple;
			}
			else{

				TupleReader readerGetNext;
				try
				{
					readerGetNext = new TupleReader(fileUrl, RIdNext.getPageId(), RIdNext.getTupleId());
					Tuple returnedTuple = new Tuple(table, alias, readerGetNext);
					readerGetNext.close();
					if(alias == null) returnedTuple.setName(table);

					return returnedTuple;

				}catch(IOException e)
				{
					e.printStackTrace();
				}

				Tuple returnedTuple = new Tuple(table, alias, reader);
				returnedTuple.setName("ENDOFFILE");
				return returnedTuple;
			}


		}
		else{
			//We simply scan through the normal db file until we reach highkey or EOF	
			System.out.println(" am i going into clustering?");

			if (reader == null) System.out.println("reader is null!");
			Tuple returnedTuple = new Tuple(table, alias, reader);
			System.out.println("ISO: " + returnedTuple.getValues());
			System.out.println("ISO Highkey: "+ this.highkey);
			////System.out.println("yup definitely the reade2r");

			if (alias == null){
				//System.out.println("setting name to " + table);
				returnedTuple.setName(table);
			}

			//check if reached end OR reached a tuple greater than highkey. END


			//System.out.println("Attr is" + attr);
			//System.out.println("reader arraylist is: "+ reader.getArrayList().toString());
			if (reader.getArrayList().isEmpty()||returnedTuple.getValues() == null || returnedTuple.getValues().size() == 0 ) {

				System.out.println("dahusjai");
				returnedTuple.setName("ENDOFFILE");
			}
			else{

				if ((int) returnedTuple.getValues().get(attr) > highkey){
					System.out.println("okokokaokokjojo2");
					returnedTuple.setName("ENDOFFILE");
				}
			}

			////System.out.println("yup definitely the reader");

			return returnedTuple;

		}


	}

	/**
	 * Resets this operator to the first tuple
	 */
	@Override
	public void reset() {
		td.bufferCtr = 0;
		System.out.println("ISO: resetting");
		if(cluster== 1)
		{
			try {
				
				reader.close();
				reader = new TupleReader(fileUrl, first.getPageId(), first.getTupleId());
				//td.getNextRId();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	/**
	 * Resets this operator to the tuple at index
	 * @param index
	 */
	@Override
	public void reset(int index) {
		td.bufferCtr = index;

	}

	/**
	 * Gets every tuple from this operator
	 */
	@Override
	public void dump() throws IOException {

	}

}
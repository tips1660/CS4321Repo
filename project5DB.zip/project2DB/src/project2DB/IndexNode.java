package project2DB;

import java.util.ArrayList;

/**
 * IndexNode is the class representing an index node of a BPlusTree
 * @author Robert Cao rrc8 Pulkit Kashyap pk374 Jason Zhou jz629
 */
public class IndexNode extends TreeNode{
	
	ArrayList<TreeNode> children = new ArrayList<TreeNode>();
	ArrayList<Integer> keys = new ArrayList<Integer>();
    int smallest  = Integer.MAX_VALUE;
    public int pageNumber;
    ArrayList<Integer> childPages = new ArrayList<Integer>();
    
    /**
     * Gets the children of this node
     * @return children
     */
	public ArrayList<TreeNode> getChildren() {
		return children;
	}
	
	/**
	 * Sets the children of this node
	 * @param children
	 */
	public void setChildren(ArrayList<TreeNode> children) {
		this.children = children;
	}
	
	/**
	 * Gets the keys of this node
	 * @return keys
	 */
	public ArrayList<Integer> getKeys() {
		return keys;
	}
	
	/**
	 * Sets the keys of this node
	 * @param keys
	 */
	public void setKeys(ArrayList<Integer> keys) {
		this.keys = keys;
	}
	
	/**
	 * Gets the smallest key
	 * @return smallest
	 */
	@Override
	public int getSmallestKey() {
		 
		 return smallest;
	}
	
	/**
	 * Sets the smallest key
	 * @param smallestKey
	 */
	public void setSmallestKey(int smallestKey) {
		this.smallest = smallestKey;
		
	}
	
	/**
	 * Sets the child pages
	 * @param children2
	 */
	public void setChildPages(ArrayList<Integer> children2) {

		childPages = children2;
	}

	/**
	 * Gets the child pages
	 * @return childPages
	 */
	public ArrayList<Integer> getChildPages() {

		return childPages;
	}

	
	

}

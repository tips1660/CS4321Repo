package project2DB;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import  java.util.*;
import logicalOperators.PhysicalPlanBuilder;

/**
 * This class makes a DatabaseCatalog using singleton method. 
 * @author Pulkit Kashyap pk374 Robert Cao rrc85 Jason Zhou jz629
 */
public final class DatabaseCatalog {
	private static DatabaseCatalog dbcat = new DatabaseCatalog();
	private Hashtable<String, tableProperties> tableMatcher = new Hashtable<String, tableProperties>();
	static File schemaName;
	static File[] tableLocations;
	static File[] indexes;
	static String inputDirectory = "";
	HashMap<String, List<String>> tableToIndex = new HashMap<String, List<String>>();						
	HashMap<String, Map<String,Integer>> indexToCluster = new HashMap<String, Map<String,Integer>>();	//changed to another map
	HashMap<String, Map<String,Integer[]>> tableMinMax = new HashMap<String,Map<String,Integer[]>>();	//Tracks the min and max of each attr for each table
	HashMap<String, Integer> tableNumTuples = new HashMap<String, Integer>();							//Tracks the num of tuples in each table
	HashMap<String, Integer> tableToLeaves = new HashMap<String, Integer>();		//Tracks the num of leaves per index 
	HashMap<String, Integer> idxHeights = new HashMap<String, Integer>();
	private DatabaseCatalog() 
	{
	}

	/**
	 * Starts Schema Parsing
	 * @throws MalformedURLException
	 */
	public void startParseSchema() throws MalformedURLException
	{

		try {
			parseSchema();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 *  Sets the Schema to the passed in File
	 * 
	 * @param File
	 *            the node to be visited
	 */
	public void setSchemaName(File s)
	{
		schemaName = s;
	}

	/**
	 * Sets the file directory where all of the tables are stored
	 * 
	 * @param s
	 *            
	 */
	public void setTableLocation(File[] s)
	{
		tableLocations = s;
	}

	/**
	 * Method for obtaining the database catalog; just returns dbcat
	 * @return DatabaseCatalog
	 *            returns the DatabaseCatalog for lookup operations
	 */
	public static DatabaseCatalog getInstance()
	{
		return dbcat;
	}

	/**
	 * Method for obtaining the database catalog; just returns tableMatcher
	 * @return DatabaseCatalog
	 *            returns the DatabaseCatalog for lookup operations
	 */
	public Hashtable<String, tableProperties> getTableCatalog()
	{
		return tableMatcher;
	}

	/**
	 * @param t
	 * Sets the Input Directory
	 */
	public void setInputDirectory(String t)
	{
		inputDirectory = t;
	}

	/**
	 * parseSchema takes in the absolute path to the schema file, and will scan
	 * each table for its schema, and then create the tableMatcher
	 * @throws FileNotFoundException, MalformedURLException
	 */
	public void parseSchema() throws FileNotFoundException, MalformedURLException
	{
		File schema = schemaName;//new File("C:\\Users\\pulki_000\\Desktop\\dbpracproj2\\samples\\input\\db\\schema.txt");
		Scanner scan = new Scanner(schema);
		while(scan.hasNextLine())
		{
			String currentLine = scan.nextLine();
			String tableName = "";
			tableProperties table = new tableProperties();
			int leftPtr =0;
			for(int i =0; i<currentLine.length(); i++)
			{  
				if(tableName == ""){
					if(currentLine.charAt(i) == ' ')	
					{
						tableName = currentLine.substring(leftPtr, i);
						leftPtr = i+1;
						table.setName(tableName);

					}

				}
				else{
					if(currentLine.charAt(i) == ' '){
						table.addColumn(currentLine.substring(leftPtr, i));
						leftPtr = i+1;
					}
				}
			} 
			table.addColumn(currentLine.substring(leftPtr, currentLine.length()));
			String s;
			for (int i = 0; i < tableLocations.length; i++) {
				String checker = inputDirectory + File.separator + "db" + File.separator + "data" + File.separator + tableName;
				////System.out.println(checker);
				////System.out.println(tableLocations[i].getPath());
				if (checker.equals(tableLocations[i].getPath())) {
					////System.out.println(tableLocations[i].toURI().toURL().toString().substring(5));
					table.setUrl(tableLocations[i].toURI().toURL().toString().substring(5));
				}

			}
			tableMatcher.put(tableName, table);
		}
		scan.close();
	}

	/**
	 * Sets the location of the directory where all the indexes are stored
	 * @param idx
	 */
	public void setIndexesDirectory(File[] idx) 
	{
		indexes = idx;
	}

	/**
	 * Gets the list of indexes of a table, if it exists
	 * @param s the name of the table
	 * @return t, the list of indexes of the table
	 */
	public List<String> getIndexes(String s)
	{
		return tableToIndex.get(s);
	}

	/**
	 * Gets the clustered or unclustered flag from an index
	 * @param s the name of the table
	 * @param a the name of the attribute of the table
	 * @return i, the clustering flag
	 */
	public int getCluster(String s, String a) 
	{
		Integer i = indexToCluster.get(s).get(s+"."+a);
		if (i == null)
			i = 0;
		return i;
	}

	/**
	 * Gets the index file from the indexes directory of s
	 * @param s in the form of TABLE.ATTR
	 * @return f
	 */
	public File getFile(String s)
	{
		for (File f: indexes)
		{
			if (f.getName().equals(s))
				return f;
		}
		return null;
	}

	/**
	 * Sets the tableToIndex hashmap
	 * @param tableToIndex2
	 */
	public void setTableToIndex(HashMap<String, List<String>> tableToIndex2) {
		tableToIndex = tableToIndex2;
	}

	/**
	 * Sets the indexToCluster hashmap
	 * @param m
	 */
	public void setIndexToCluster(HashMap<String, Map<String,Integer>> m) {
		indexToCluster = m;
	}

	/**
	 * 
	 * @param table The Table being referenced
	 * @param attr	The attr in the form of Table.attr
	 * @param min	The minimum value of that attribute in the Table
	 * @param max	The maximum value of that attribute in the Table
	 */
	public void setMinMax(String table, String attr, Integer min, Integer max){

		Integer[] temp = {min,max};

		//First entry for this table
		if (!tableMinMax.containsKey(table)){
			HashMap<String, Integer[]> newEntry = new HashMap<String,Integer[]>();
			newEntry.put(attr, temp);
			tableMinMax.put(table, newEntry);
		}
		else{
			tableMinMax.get(table).put(attr, temp);
		}
	}

	/**
	 * 
	 * @param table the table being referenced
	 * @param num	the number of tuples in table
	 */
	public void setNumTuples(String table, Integer num){
		tableNumTuples.put(table, num);
	}

	/**
	 * 
	 * @param table the table being referenced
	 * @param attr	the attribute being referenced
	 * @return		minimum value of the attribute being referenced
	 */
	public Integer getMin(String table, String attr){
		return tableMinMax.get(table).get(attr)[0];
	}


	/**
	 * 
	 * @param table the table being referenced
	 * @param attr	the attribute being referenced
	 * @return		maximum value of the attribute being referenced
	 */
	public Integer getMax(String table, String attr){
		return tableMinMax.get(table).get(attr)[1];
	}

	/**
	 * 
	 * @param table the table being referenced
	 * @return		the number of tuples in the table being referenced
	 */
	public Integer getNumTuples(String table){
		return tableNumTuples.get(table);
	}


	/**
	 * 
	 * @param indexName the name of the index in the form of "table.attr"
	 * @param i			the number of leaves in the index
	 */
	public void setLeaves(String indexName, Integer i){
		tableToLeaves.put(indexName,i);
	}

	/**
	 * 
	 * @param indexName	the name of the index in the form of "table.attr"
	 * @return	the number of leaves in the index with name "indexName"
	 */
	public Integer getLeaves(String indexName){
		return tableToLeaves.get(indexName);
	}

	public void addIndexHeight(String key, int treeHeight) {

		idxHeights.put(key, treeHeight);
	}
	public int getIndexHeight(String key)
	{
		return idxHeights.get(key);
	}
}

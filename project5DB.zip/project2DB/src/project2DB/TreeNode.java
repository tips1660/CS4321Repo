package project2DB;

/**
 * TreeNode is the abstract class representing a basic tree node
 * @author Robert Cao rrc8 Pulkit Kashyap pk374 Jason Zhou jz629
 */
public abstract class TreeNode {
	/**
	 * Returns the smallest key in the node
	 * @return smallestKey
	 */
	public abstract int getSmallestKey();
}

package project2DB;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;

/**
 * TupleReader is a class that reads tuples from a file.
 * @author Robert Cao rrc8 Pulkit Kashyap pk374
 */
public class TupleReader {

	private String fName = "";
	private FileInputStream fin;
    private FileChannel fc;
    private ByteBuffer buffer = ByteBuffer.allocate(4096);
    private int numAttributes;
    private int numTuples;
    private int currentTuple;
    private int currentByte;
    private ArrayList<Integer> tuple;
    private int currentPage = -1;
    private int tupleNum = -1;
  
    //Constructor for index scan to handle lowkey
    public TupleReader(String fileName, Integer pageID, Integer tupleID) throws IOException{
    	tuple = new ArrayList<Integer>();
    	fName = fileName;
    	fin = new FileInputStream(fName);
    	fc = fin.getChannel();
    	currentTuple = 0;
    	//set the scan to begin reading at the given pid, tid
    	buffer.clear();
		buffer.put(new byte[4096]);
		buffer.clear();
		
		long index = 4096 * pageID;
		fc.position(index);
		getNextPage();
		
		//potential off by one error based on indexing?
		while (currentTuple < tupleID){
			tuple = getNextTuple();
		}
		
    }
    
    public TupleReader(String fileName) throws IOException {
    	tuple = new ArrayList<Integer>();
    	fName = fileName;
    	//System.out.println(fName.toString());
    	//System.out.println("fname is: " + fName);
    	fin = new FileInputStream(fName);
    	fc = fin.getChannel();
    	getNextPage();
    }
    
    public TupleReader() throws IOException {
    	
    }
    
    /**
     * Closes this tuple reader
     * @throws IOException
     */
    public void close() throws IOException {
    	fin.close();
    }
    
    /**
     * Changes the file of the tuple reader
     * @param fileName
     * @throws IOException
     */
    public void changeFile(String fileName) throws IOException {
    	tuple = new ArrayList<Integer>();
    	fName = fileName;
    	////System.out.println(fName.toString());
    	fin = new FileInputStream(fName);
    	fc = fin.getChannel();
    	getNextPage();
    }
    
    /**
     * Gets the next page of the file
     * @return
     * @throws IOException
     */
    public int getNextPage() throws IOException {
    	tupleNum=-1;
    	currentPage+=1;
    	currentTuple = 0;
    	buffer.clear();
    	int numBytes = fc.read(buffer);
    	////System.out.println("getNextPage was called");
    	if (numBytes != -1)
    		setInfo();
    	return numBytes;
    }
    
    /**
     * Override to handle getting a specific page, for unclustered index use.
     * @param pageNum
     * @return
     * @throws IOException
     */
    public int getNextPage(int pageNum) throws IOException{
    	tupleNum = -1;
    	currentPage = pageNum;
    	buffer.clear();
    	fc.position(4096*pageNum);
    	int numBytes = fc.read(buffer);
    	if (numBytes != -1) setInfo();
    	return numBytes;

    }
    
    /**
     * Reads the metaData of a page
     */
    public void setInfo() {
    	numAttributes = buffer.getInt(0);
    	////System.out.println(numAttributes);
    	numTuples = buffer.getInt(4);
    	////System.out.println(numTuples + " setInfo called");
    	currentTuple = 0;
    	currentByte = 8;
    }
    
    /**
     * Gets the number of attributes on the page
     * @return numAttributes
     */
    public int getNumAttributes() {
    	return numAttributes;
    }
    
    /**
     * Gets the number of tuples on the page
     * @return numTuples
     */
    public int getNumTuples() {
    	return numTuples;
    }
    
    /**
     * Return the arraylist representing the value of a tuple's columns
     * @return tuple
     */
    public ArrayList<Integer> getArrayList() {
    	return tuple;
    }
    
    /**
     * Return the arraylist representing the value of the next tuple's columns
     * @return tuple
     */
    public ArrayList<Integer> getNextTuple() throws IOException {
    	if (!tuple.isEmpty())
    		tuple.clear();
    	int numBytes = 0;
    	if (!(currentTuple < numTuples)) {
    		//buffer.clear();
    		numBytes = getNextPage();
    	}
    	if (numBytes != -1) {
    		int currentAttribute = 0;
    		tupleNum++;
    		while (currentAttribute < numAttributes) {
    			currentAttribute++;
    			////System.out.print(buffer.getInt(currentByte) + " ");
    			tuple.add(buffer.getInt(currentByte));
    			currentByte += 4;
    		}
    		////System.out.println();
    	}
    	currentTuple++;
    	return tuple;
    }
    
    /**
     * 
     * @param tupleID specific tupleID on the page to return
     * @return the tupleID'th tuple on the given page
     * @throws IOException
     */
    public ArrayList<Integer> getNextTuple(int tupleID) throws IOException {
    	//set current byte to the beginning of the tupleID on the page
    	currentByte = 8 + tupleID*numAttributes;
    	
    	if (!tuple.isEmpty()) tuple.clear();

		int currentAttribute = 0;
		tupleNum = tupleID;
		while (currentAttribute < numAttributes) {
			currentAttribute++;
			////System.out.print(buffer.getInt(currentByte) + " ");
			tuple.add(buffer.getInt(currentByte));
			currentByte += 4;
		}
    		////System.out.println();
    	
    	currentTuple++;
    	return tuple;
    }
    
    /**
     * Gets the number of tuple on the page
     * @return tupleNum
     */
    public int getTupleNum()
    {
    	return tupleNum;
    }
    
    /**
     * Gets the page number of the current page
     * @return currentPage
     */
    public int getPage()
    {
    	return currentPage;
    }
}
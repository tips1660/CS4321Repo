package project2DB;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import net.sf.jsqlparser.expression.*;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
import net.sf.jsqlparser.expression.operators.relational.GreaterThan;
import net.sf.jsqlparser.expression.operators.relational.GreaterThanEquals;
import net.sf.jsqlparser.expression.operators.relational.MinorThan;
import net.sf.jsqlparser.expression.operators.relational.MinorThanEquals;
import net.sf.jsqlparser.schema.*;
import project2DB.*;

/**
 * Static optimizer class that will accumulate info on all attributes on a select and
 * calculate the IO costs to determine which select query plan to build
 * @author jasonzhou, Pulkit Kashyap, Robert Cao
 *
 */
public class SelectOptimizer {
	
	
	static HashMap<String,Integer[]> attributeInfo = new HashMap<String,Integer[]>();		//Keep track of min, max for each attr in select
	static List<String> attributes = new ArrayList<String>(); 								//Keep track of all relevant attr
	static List<Double> costs = new ArrayList<Double>();									//Keep track of all costs
	static HashMap<String,Double> attrToCost = new HashMap<String,Double>();				//Maps attribute->cost
	static Double scanCost = (double) -1;
	static DatabaseCatalog dbcat = DatabaseCatalog.getInstance();	
	
	/**
	 * chooseIndex will decide which index to use on a table if multiple indices exist.
	 * 
	 * @param table the table under consideration
	 * @param e		the WHERE clause of a select expression which will be an AND of attr OP val or attr = attr 
	 * @return      the indexName (table.attr) of the best index, or null if normal scan is the best option
	 */
	public static String chooseIndex(String table, Expression e){
		System.out.println("SELECTOPT1");
		System.out.println(e.toString());
		//collect all "attr OP val expressions"
		Expression temp_e = e;
		ArrayList<Expression> ands = new ArrayList<Expression>();
		
		if (!(temp_e instanceof AndExpression) && temp_e instanceof BinaryExpression){
			System.out.println("SelectOptimizer: Only one condition");
			ands.add(temp_e);	//case wherer there is only one select condition
		}
		else{
			while (temp_e instanceof AndExpression){
				ands.add(((AndExpression) temp_e).getRightExpression()); 
				temp_e = ((AndExpression) temp_e).getLeftExpression();
			}
		}
		
		//Processing: Loop through each Attr OP Val and add it to attributeInfo, saving the range 
		System.out.println("SelectOptimizer: Ands size is: " + ands.size());
		for (Expression condition: ands){
			Expression left = ((BinaryExpression) condition).getLeftExpression();
			Expression right = ((BinaryExpression) condition).getRightExpression();
			String attr;
			String table1;
			
			if (left instanceof Column && right instanceof LongValue){
				
				table1 = left.toString().split("\\.")[0];
				attr = left.toString().split("\\.")[1];
			}
			else if (left instanceof LongValue && right instanceof Column){
				
				table1 = right.toString().split("\\.")[0];
				attr = right.toString().split("\\.")[1];
				
			}
			else if (left instanceof Column && right instanceof Column){
				//Sailors.A = Sailors.B, Sailors.A > Sailors.B, etc.
				double numTuples = dbcat.getNumTuples(table);
				double numAttr = dbcat.getTableCatalog().get(table).getColumns().size();
				scanCost = numTuples * numAttr * 4 / 4096;
				
				continue;
			}
			else{
				//Should I even get here? 5 = 5?
				System.out.println("SelectOptimizer: Corner case?");
				throw new IllegalArgumentException();
			}
			
			Integer[] range =  findRange(condition);
			updateAttributeInfo(attr,range);
			attributes.add(attr);
			System.out.println("SelectOptimizer is Evaluating: " + condition.toString());
		}
		
		//Calculate actual costs 
		double tuples = dbcat.getNumTuples(table);
		double pages = tuples * dbcat.getTableCatalog().get(table).getColumns().size() * 4 / 4096;
		
		for (String attr: attributes){
			
			double cost = -1;
			Integer[] range = attributeInfo.get(attr);
			String indexName = table+"."+attr;
			
			//no index, so cost is the same as a scan
			if (!dbcat.getIndexes(table).contains(indexName)){
				System.out.println("There does not exist an index on "+ indexName);
				cost = pages;
			}
			else{
				//Index exists
				System.out.println("Found an index on "+ indexName);
				Integer min = dbcat.getMin(table, attr);
				Integer max = dbcat.getMax(table, attr);
				Integer tableRange = max-min;
				
				Integer myMin = (range[0] == null) ? min : range[0];
				Integer myMax = (range[1] == null) ? max : range[1];
				Integer myRange = myMax - myMin;

				double rFactor = ((double) myRange) / ((double) tableRange);	//get r-factor by dividing 
				double leaves = dbcat.getLeaves(indexName);						//get leaves from index 
				double height = (double) dbcat.getIndexHeight(indexName);
				
				System.out.println("min:"+min + " max:" + max + " tablerange:" + tableRange);
				System.out.println("myMin:"+myMin + " myMax:" + myMax + " myRange:" + myRange);
				System.out.println("rFactor:"+rFactor + " leaves:" + leaves + " height:"+height);

				//how to get root to leaf cost?
				if (dbcat.getCluster(table, attr) == 1){
					System.out.println(indexName + " is clustered");
					cost = height + pages*rFactor;								//clustered
				}
				else{
					System.out.println(indexName + " is unclustered");
					cost = height + leaves*rFactor + pages*rFactor;				//unclustered
				}
				System.out.println("Cost on "+ indexName + " is:" + cost +" baseline is: "+ pages);
				
			}
			
			costs.add(cost);
			attrToCost.put(attr,cost);
		}
		
		
		if ((scanCost != -1) && !costs.isEmpty()){
			System.out.println("Decided to scan, bye");
			for (double c:costs) if (scanCost < c) return null;			//compare to simple scan cost
		}
		
		if (costs.isEmpty()) return null;								//No other build paths
		
		Double minCost = pages;
		String chosenOne = "";
		for (String attr: attributes){
			
			if (attrToCost.get(attr) < minCost){
				minCost =  attrToCost.get(attr);
				chosenOne = attr;
			}

		}
		
		if (minCost == pages) return null;
		
		System.out.println("SelectOptimizer has chosen: "+ table+"."+chosenOne);
		clear();
		return table+"."+chosenOne;

	}
	
	/**
	 * Updates the static AttributeInfo data structure with a new entry
	 * 
	 * @param attr	the attribute of the table being referenced
	 * @param new	the range of the attribute of the table being referenced
	 */
	private static void updateAttributeInfo(String attr, Integer[] newRange){
		System.out.println("Updating Attribute information");
		if (!attributeInfo.containsKey(attr)){
			attributeInfo.put(attr, newRange); 			//Do i need to make a new object?
		}
		else{
			
			Integer[] curr = attributeInfo.get(attr);
			
			//if both ranges are null then we dont change anything
			if (newRange[0] != null){
				curr[0] = (curr[0] == null) ? newRange[0] : Math.max(curr[0], newRange[0]); //update minimum	
				attributeInfo.put(attr, curr);
			}
			if (newRange[1] != null){
				curr[1] = (curr[1] == null) ? newRange[1] : Math.min(curr[1], newRange[1]); //update maximum
				attributeInfo.put(attr,curr);
			}
		}
	}
	
	/**
	 * 
	 * @param e  		expression of the form Attr Op Val or Val Op Attr
	 * @return range 	the of values that attribute takes
	 */
	private static Integer[] findRange(Expression e){
		System.out.println("SelectOptimizer: Entering findRange");
		Expression left = ((BinaryExpression) e).getLeftExpression();
		Expression right = ((BinaryExpression) e).getRightExpression();
		
		String attribute;
		Integer value = null;
		Integer[] range = new Integer[2];
	
		boolean isLower;
		boolean isUpper;
		boolean isInclusive;
		boolean isFlipped;

		
		if (left instanceof Column && right instanceof LongValue){
			attribute = left.toString();
			value = Integer.parseInt(right.toString());
		}
		else if (left instanceof LongValue && right instanceof Column){
			attribute = right.toString();
			value = Integer.parseInt(left.toString());
		}
		else{
			//Shouldnt get here
			System.out.println("SelectOptimizer: Shouldnt have gotten here line 211");
			throw new IllegalArgumentException();
		}
		
		
		isLower = (e instanceof GreaterThan) || (e instanceof GreaterThanEquals) || (e instanceof EqualsTo);
		isUpper = (e instanceof MinorThan) || (e instanceof MinorThanEquals) || (e instanceof EqualsTo);
		isInclusive = (e instanceof GreaterThanEquals) || (e instanceof MinorThanEquals);
		isFlipped = (right instanceof Column);
		
		if (isFlipped){
			isLower = !isLower;
			isFlipped = false;
		}
		
		if (isInclusive == false) value = (isLower) ? value + 1 : value - 1;
		if (isLower) range[0] = (range[0] == null) ? value : Math.max(range[0],value);
		if (isUpper) range[1] = (range[1] == null) ? value : Math.min(range[1], value);
		
		System.out.println("SelectOptimizer: Finished findRange");
		return range;
		
	}
	
	private static void clear(){
		attributeInfo.clear();
		attributes.clear();
		costs.clear();
		attrToCost.clear();
		scanCost = (double) -1;
	}

}

package logicalOperators;

import java.io.IOException;
import java.util.ArrayList;

/**
 * LogicalOperator is an abstract class representing a logical operator. 
 * @author Pulkit Kashyap pk374 Robert Cao rrc85 Jason Zhou jz629
 */
public abstract class LogicalOperator  {
   
	LogicalOperator child;
	
	/**
	 * Sets the child of this operator
	 * @param s
	 */
	public void setChild(LogicalOperator s)
    { 
		child = s; 
    }
	
	
	/**
	 * Gets the child of this operator
	 * @return child
	 */
    public LogicalOperator getChild()
    {
    	return child;
    }
    
    /**
	 * Method for visiting this operator in a physical plan builder
	 * @param s
	 */
    public abstract void accept(PhysicalPlanBuilder s) throws IOException;
}

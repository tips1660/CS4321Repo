package project2DB;

import java.io.IOException;

import net.sf.jsqlparser.schema.Table;

/**
 * SortOperatorParent is the abstract class representing the basic structure of join operators
 * @author Robert Cao rrc8 Pulkit Kashyap pk374 Jason Zhou jz629
 */
public abstract class SortOperatorParent extends Operator {

	/**
	 * Set the table of the operator
	 * @param tableN
	 */
	public abstract void setTable(Table tableN);
			
	/**
	 * Add the param to the sortlistactual
	 * @param leftJoinExpR
	 */
	public abstract void addToSortListActual(String leftJoinExpR);
	
	/**
	 * Gets the next tuple from this operator
	 * @return returnedTuple
	 */
	public abstract Tuple getNextTuple();
	
	/**
	 * Resets this operator to the first tuple
	 */
	@Override
	public abstract void reset();
	
	/**
	 * Gets every tuple from this operator
	 */
	@Override
	public abstract void dump() throws IOException;

	/**
	 * Gets the table of this operator
	 * @return table
	 */
	public abstract Table getTable();

	/**
	 * Sorts the operator
	 * @throws IOException
	 */
	public abstract void sort() throws IOException;

			
	 
		 

}

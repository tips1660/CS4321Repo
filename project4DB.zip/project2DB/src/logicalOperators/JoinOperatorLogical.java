package logicalOperators;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.select.Join;
import net.sf.jsqlparser.statement.select.SelectItem;

/**
 * JoinOperatorLogical stores all the information needed to create a physical JoinOperator in the PhysicalPlanBuilder
 * @author Pulkit Kashyap pk374 Robert Cao rrc85 Jason Zhou jz629
 */
public class JoinOperatorLogical extends LogicalOperator{

	Table tableN;
    List<Join> jList;
    Expression e;
    ArrayList<SelectItem> items;
    
    /**
	 * Gets the table of the base relation
	 * @return tableN
	 */
	public Table getTableN() {
		return tableN;
	}
	
	/**
	 * Sets the table of the base relation
	 * @param tableN
	 */
	public void setTableN(Table tableN) {
		this.tableN = tableN;
	}
	
	/**
	 * Get the list of joins
	 * @return jList
	 */
	public List<Join> getjList() {
		return jList;
	}
	
	/**
	 * Sets the list of joins
	 * @param jList
	 */
	public void setjList(List<Join> jList) {
		this.jList = jList;
	}
	
	/**
	 * Get the expression of the query
	 * @return e
	 */
	public Expression getE() {
		return e;
	}
	
	/**
	 * Set the expression of the query
	 * @param e
	 */
	public void setE(Expression e) {
		this.e = e;
	}
	
	/**
	 * Set the select items 
	 * @param items1
	 */
	public void setItems(ArrayList<SelectItem> items1) {
		items = items1;
		
	}
	
	/**
	 * Get the select items 
	 * @return
	 */
	public ArrayList<SelectItem> getItems()
	{
		return items;
	}
	
	/**
	 * Method for visiting this operator in a physical plan builder
	 * @param s
	 */
	@Override
	public void accept(PhysicalPlanBuilder s) throws IOException {
         s.visit(this);		
	}

}

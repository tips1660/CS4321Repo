package logicalOperators;

import java.util.ArrayList;
import java.util.Hashtable;

import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;

public class VValues {

	private Hashtable<Column, Integer> values = new Hashtable<Column,Integer>();
	private String name = "";
	private ArrayList<Table> names = new ArrayList<Table>();
	
	public VValues()
	{
		
	}
	
	public VValues(ArrayList<Table> n, Hashtable<Column, Integer> v)
	{
		names = n;
		values = v;
	}
	
	public Hashtable<Column, Integer> getValues() {
		return values;
	}
	public void setValues(Hashtable<Column, Integer> values) {
		this.values = values;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}

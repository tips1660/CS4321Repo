package logicalOperators;

import java.io.File;
import java.io.IOException;

import net.sf.jsqlparser.schema.Table;

/**
 * IndexScanOperatorLogical stores all the information needed to create a physical IndexScanOperator in the PhysicalPlanBuilder
 * @author Pulkit Kashyap pk374 Robert Cao rrc85 Jason Zhou jz629
 */
public class IndexScanOperatorLogical extends LogicalOperator {

	
	/**
	 * Gets the table of the base relation
	 * @return tableN
	 */
	public Table getTableN() {
		return tableN;
	}
	
	/**
	 * Sets the table of the base relation
	 * @param tableN
	 */
	public void setTableN(Table tableN) {
		this.tableN = tableN;
	}
	
	/**
	 * Gets the indexfile of the relation 
	 * @return indexfile
	 */
	public File getFile() {
		return indexFile;
	}
	
	/**
	 * Set the indexfile of the relation
	 * @param f
	 */
	public void setFile(File f) {
		indexFile = f;
	}
	
	/**
	 * Get the column the relation is indexed on
	 * @return attr
	 */
	public String getAttr() {
		return attr;
	}
	
	/**
	 * Set the column the relation is indexed on
	 * @param s
	 */
	public void setAttr(String s) {
		attr = s;
	}
	
	/**
	 * Get the flag representing a clustered or unclustered index for this relation
	 * @return cluster
	 */
	public int getCluster() {
		return cluster;
	}
	
	/**
	 * Set the flag representing a clustered or unclustered index for this relation
	 * @param i
	 */
	public void setCluster(int i) {
		cluster = i;
	}
	
	/**
	 * Get the high key of the current query
	 * @return high
	 */
	public int getHigh() {
		return high;
	}
	
	/**
	 * Set the high key of the current query
	 * @param i
	 */
	public void setHigh(int i) {
		high = i;
	}
	
	/**
	 * Get the low key of the current query
	 * @return low
	 */
	public int getLow() {
		return low;
	}
	
	/**
	 * Set the low key of the current query
	 * @param i
	 */
	public void setLow(int i) {
		low = i;
	}
	
	Table tableN;
	File indexFile;
	String attr;
	int cluster;
	int low;
	int high;
	
	/**
	 * Method for visiting this operator in a physical plan builder
	 * @param s
	 */
	@Override
	public void accept(PhysicalPlanBuilder s) throws IOException {
		// TODO Auto-generated method stub
	    s.visit(this);
		
	}

}

package project2DB;

/**
 * TupleS is a wrapper class containing a tuple as well as the number of the reader from which the tuple was read from
 * @author Robert Cao rrc8 Pulkit Kashyap pk374
 */
public class TupleS {

	public Tuple t;
	public int i;
	
	public TupleS(int i, Tuple t)
	{
		this.t = t;
		this.i = i;
	}
	
	/**
	 * Return the number of the reader the tuple came from
	 * @return i
	 */
	public int getReader()
	{
		return i;
	}
	
	/**
	 * Set the number of the reader the tuple came from
	 * @param i
	 */
	public void setReader(int i)
	{
		this.i = i;
	}
	
	/**
	 * Get the tuple
	 * @return t
	 */
	public Tuple getTuple()
	{
		return t;
	}
	
	/**
	 * Set the tuple
	 * @param t
	 */
	public void setTuple(Tuple t)
	{
		this.t = t;
	}
}

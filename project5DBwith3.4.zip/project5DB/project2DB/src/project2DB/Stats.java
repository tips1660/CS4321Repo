package project2DB;

public class Stats {

	private String name = "";
	private int numTuples;
	private int max;
	private int min;
	private int reductionFactor = 0;
	
	public Stats() {
		max = 0;
		min = 0;
		numTuples = 0;
	}
	
	public Stats(int n, int mi, int ma)
	{
		numTuples = n;
		max = ma;
		min = mi;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNumTuples() {
		return numTuples;
	}

	public void setNumTuples(int numTuples) {
		this.numTuples = numTuples;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}
	
	
}

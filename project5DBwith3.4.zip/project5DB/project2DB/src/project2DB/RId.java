package project2DB;

import java.util.Comparator;

/**
 * RId is the class representing the RId of a tuple. 
 * @author Robert Cao rrc8 Pulkit Kashyap pk374 Jason Zhou jz629
 */
public class RId {
	int pageId;
	int tupleId;

	/**
	 * Gets the pageId of the RId 
	 * @return pageId
	 */
	public int getPageId() {
		return pageId;
	}
	
	/**
	 * Sets the pageId of the RId
	 * @param pageId
	 */
	public void setPageId(int pageId) {
		this.pageId = pageId;
	}
	
	/**
	 * Gets the tupleId of the RId
	 * @return tupleId
	 */
	public int getTupleId() {
		return tupleId;
	}
	
	/**
	 * Sets the tupleId of the RId
	 * @param tupleId
	 */
	public void setTupleId(int tupleId) {
		this.tupleId = tupleId;
	}
	
	public RId (int pageNum, int tupleNum)
	{
		this.pageId = pageNum;
		this.tupleId = tupleNum;
	}
	

	 public static Comparator<RId> ridComparator = new Comparator<RId>()
			 {
		 	/**
		 	 * Compare 2 RIds, return -1 if o1 < o2, 1 if o1 > o2, and 0 if o1 = o2
		 	 * @param o1
		 	 * @param o2
		 	 * @return value
		 	 */
			@Override
			public int compare(RId o1, RId o2) {
				if(o1.getPageId() < o2.getPageId())
					return -1;
				else if(o1.getPageId() > o2.getPageId())
					return 1;
				else
					if ( o1.getTupleId() < o2.getTupleId() )
						return -1;
					else if(o1.getTupleId() > o2.getTupleId())
						return 1;
					else
						return 0;
				
			}
		};
	}

package project2DB;

import java.util.ArrayList;

import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.operators.relational.MinorThanEquals;
import net.sf.jsqlparser.schema.Column;

public class UnionFindElement {

	private ArrayList<Column> attributes = new ArrayList<Column>();
	private Integer lowerBound = -1;
	private Integer upperBound = Integer.MAX_VALUE;
	private Integer equal =null;
	
	public UnionFindElement(Column attr)
	{
		attributes.add(attr);
	}
	public UnionFindElement() {
		// TODO Auto-generated constructor stub
	}
	public ArrayList<Column> getAttributes() {
		return attributes;
	}
	public void setAttributes(ArrayList<Column> attributes) {
		this.attributes = attributes;
	}
	public Integer getLowerBound() {
		return lowerBound;
	}
	public void setLowerBound(Integer lowerBound) {
		this.lowerBound = lowerBound;
	}
	public Integer getUpperBound() {
		return upperBound;
	}
	public void setUpperBound(Integer upperBound) {
		this.upperBound = upperBound;
	}
	public Integer getEqual() {
		return equal;
	}
	public void setEqual(Integer equal) {
		this.equal = equal;
		if(this.equal !=null)
		{
			lowerBound = equal;
			upperBound = equal;
		}
	}
	
	 
}

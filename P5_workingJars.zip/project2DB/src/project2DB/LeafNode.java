package project2DB;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;

/**
 * LeafNode is the class representing the leaf nodes of a BPlusTree
 * @author Robert Cao rrc8 Pulkit Kashyap pk374 Jason Zhou jz629
 */
public class LeafNode extends TreeNode{	
	Hashtable <Integer, ArrayList<RId>> dataEntry = new Hashtable <Integer, ArrayList<RId>>();
	int smallestKey = Integer.MAX_VALUE;
	public int pageNumber;

	public LeafNode()
	{
		
	}
	
	public LeafNode(Hashtable <Integer, ArrayList<RId>> h, int p)
	{
		dataEntry = h;
		pageNumber = p;
	}
	
	/**
	 * Sorts RIds that share the same key.
	 * @param key
	 */
	public void sort(int key)
	{
		Collections.sort(dataEntry.get(key), RId.ridComparator);
	}
	
	/**
	 * Gets the dataEntrys of the leafNode
	 * @return dataEntry
	 */
	public Hashtable<Integer, ArrayList<RId>> getDataEntry()
	{
		return dataEntry;
	}

	/**
	 * Gets the smallest key of the node 
	 * @return smallestKey
	 */
	public int getSmallestKey()
	{
		return smallestKey;
	}
	
	/**
	 * Sets the smallest key of the node
	 * @param key
	 */
	public void setSmallestKey(int key)
	{
		this.smallestKey   = key;
	}

	/**
	 * Prints the RIds of the node
	 */
	public void printStuff()
	{
		ArrayList<Integer> keys = new ArrayList<Integer>();
		Object[] arr = dataEntry.keySet().toArray();
		for(int i =0; i<arr.length; i++)
		{
			keys.add((int)arr[i]);
		}
		Collections.sort(keys);
		for(int i =0; i<keys.size(); i++)
		{

			
			ArrayList<RId> values = dataEntry.get(keys.get(i));
			System.out.print(keys.get(i)+ ":[ ");
			for(int j = 0; j< values.size(); j++)
			{
				System.out.print("(" + values.get(j).pageId + ", " + values.get(j).tupleId + "); ");
			}
			System.out.print("]");
			System.out.println();
		}

	}
	
	/**
	 * Sets the dataEntry
	 * @param dataEntries
	 */
	public void setDataEntry(Hashtable<Integer, ArrayList<RId>> dataEntries) {
	    dataEntry = dataEntries;
		
	}
	
	/**
	 * Sets the page
	 * @param page
	 */
	public void setPage(int page)
	{
		pageNumber = page;
	}
	
	/**
	 * Gets the page
	 * @return
	 */
	public int getAddress() {
		return pageNumber;
	}
}



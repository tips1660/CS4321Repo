package logicalOperators;

import java.io.IOException;

import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.schema.Table;

/**
 * SelectLogical stores all the information needed to create a physical SelectOperator in the PhysicalPlanBuilder
 * @author Pulkit Kashyap pk374 Robert Cao rrc85 Jason Zhou jz629
 */
public class SelectOperatorLogical extends LogicalOperator{
	Table tableN;
	Expression input;
  
	/**
	 * Gets the table of the base relation
	 * @return tableN
	 */
	public Table getTableN() {
		return tableN;
	}
  
	/**
	 * Sets the table of the base relation
	 * @param tableN
	 */
	public void setTableN(Table tableN) {
		this.tableN = tableN;
	}
	
	/**
	 * Gets the select expression of this query
	 * @return input
	 */
	public Expression getInput() {
		return input;
	}
	
	/**
	 * Sets the select expression of this query
	 * @param input
	 */
	public void setInput(Expression input) {
		this.input = input;
	}

	/**
	 * Method for visiting this operator in a physical plan builder
	 * @param s
	 */
	@Override
	public void accept(PhysicalPlanBuilder s) throws IOException {
		s.visit(this);
	}

}

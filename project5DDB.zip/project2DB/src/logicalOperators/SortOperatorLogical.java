package logicalOperators;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.select.Join;
import net.sf.jsqlparser.statement.select.OrderByElement;
import net.sf.jsqlparser.statement.select.SelectItem;

/**
 * SortOperatorLogical stores all the information needed to create a physical SortOperator in the PhysicalPlanBuilder
 * @author Pulkit Kashyap pk374 Robert Cao rrc85 Jason Zhou jz629
 */
public class SortOperatorLogical extends LogicalOperator{
	
	/**
	 * Returns the name of the file to be written to
	 * @return out
	 */
   public String getOut() {
		return out;
	}

   /**
	 * Sets the name of the file to be written to
	 * @param out
	 */
	public void setOut(String out) {
		this.out = out;
	}
	
	/**
	 * Gets the location of the temp directory, for external sorting
	 * @return tempdir
	 */
	public String getTemp() {
		return tempdir;
	}

	/**
	 * Sets the location of the temp directory, for external sorting
	 * @param temp
	 */
	public void setTemp(String temp) {
		tempdir = temp;
	}

	/**
	 * Gets the list of selectitems
	 * @return items1
	 */
	public ArrayList<SelectItem> getItems1() {
		return items1;
	}

	/**
	 * Sets the list of selectitems 
	 * @param items1
	 */
	public void setItems1(ArrayList<SelectItem> items1) {
		this.items1 = items1;
	}

	/**
	 * Gets the list of order by elements
	 * @return orderList
	 */
	public List<OrderByElement> getOrderList() {
		return orderList;
	}

	/**
	 * Sets the list of order by elements
	 * @param orderList
	 */
	public void setOrderList(List<OrderByElement> orderList) {
		this.orderList = orderList;
	}

	/**
	 * Gets the query number
	 * @return queryNum
	 */
	public int getQuery() {
		return querynum;
	}
	
	/**
	 * Sets the query number
	 * @param q
	 */
	public void setQuery(int q) {
		querynum = q;
	}

	String out;
	String tempdir;
	ArrayList<SelectItem> items1;
	List<OrderByElement> orderList;
	int querynum;
	
	/**
	 * Method for visiting this operator in a physical plan builder
	 * @param s
	 */
	public void accept(PhysicalPlanBuilder s) throws IOException
	{
		s.visit(this);
	}
	
	
}

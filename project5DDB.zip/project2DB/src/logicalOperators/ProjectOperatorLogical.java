package logicalOperators;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.select.Join;
import net.sf.jsqlparser.statement.select.SelectItem;

/**
 * ProjectOperatorLogical stores all the information needed to create a physical ProjectOperator in the PhysicalPlanBuilder
 * @author Pulkit Kashyap pk374 Robert Cao rrc85 Jason Zhou jz629
 */
public class ProjectOperatorLogical extends LogicalOperator {
	
	/**
	 * Returns the name of the file to be written to
	 * @return out
	 */
    public String getOut() {
		return out;
	}

    /**
	 * Sets the name of the file to be written to
	 * @param out
	 */
	public void setOut(String out) {
		this.out = out;
	}

	/**
	 * Returns the selectitems
	 * @return items
	 */
	public ArrayList<SelectItem> getItems() {
		return items;
	}

	/**
	 * Sets the selectitems 
	 * @param items
	 */
	public void setItems(ArrayList<SelectItem> items) {
		this.items = items;
	}

	/**
	 * Gets the list of joins
	 * @return joinList
	 */
	public List<Join> getJoinList() {
		return joinList;
	}

	/**
	 * Sets the list of joins
	 * @param joinList
	 */
	public void setJoinList(List<Join> joinList) {
		this.joinList = joinList;
	}

	/**
	 * Gets the table of the base relation
	 * @return tableN
	 */
	public Table getTableN() {
		return tableN;
	}

	/**
	 * Sets the table of the base relation
	 * @param tableN
	 */
	public void setTableN(Table tableN) {
		this.tableN = tableN;
	}

	public String out;
    public ArrayList<SelectItem> items;
    List<Join> joinList;
    Table tableN;
    
    /**
	 * Method for visiting this operator in a physical plan builder
	 * @param s
	 */
	@Override
    public void accept(PhysicalPlanBuilder s) throws IOException
    {
    	s.visit(this);
    }
    
}

package project2DB;

import java.util.ArrayList;

import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.parser.CCJSqlParser;
import net.sf.jsqlparser.schema.Column;

public class UnionFind {
      private ArrayList<UnionFindElement> unionList = new ArrayList<UnionFindElement>();
      private ArrayList<Expression> rejectedExp = new ArrayList<Expression>();
      
      public ArrayList<Expression> getRejectedExp() {
		return rejectedExp;
	}
	public void setRejectedExp(ArrayList<Expression> rejectedExp) {
		this.rejectedExp = rejectedExp;
	}
	public ArrayList<UnionFindElement> getUnionList() {
		return unionList;
	}
	public void setUnionList(ArrayList<UnionFindElement> unionList) {
		this.unionList = unionList;
	}
	public UnionFind()
      {
    	  
      }
      public UnionFindElement find(Column attr)
      {
    	  for(UnionFindElement a: unionList)
    	  {
    		  if(a.getAttributes().contains(attr))
    			  return a;
    	  }
    	  UnionFindElement newElem = new UnionFindElement(attr);
    	  unionList.add(newElem);
    	  return newElem;
    	  
      }
      
      
      public void union(UnionFindElement a, UnionFindElement b)
      {
    	  UnionFindElement c = new UnionFindElement();
    	  unionList.remove(a);
    	  unionList.remove(b); //assumes that both of these are in the UnionList
    	  if(a.getLowerBound() < b.getLowerBound())
    	  {
    		  c.setLowerBound(a.getLowerBound());
    	  }
    	  
    	 
    	  if(a.getEqual() !=null) {
    		  c.setEqual(a.getEqual());
    	  }
    	  else if(b.getEqual() !=null) {//going by the assumption that we don't have two different equals.
    		  c.setEqual(b.getEqual());
    	  }
    	  else {
    		  c.setLowerBound((a.getLowerBound() < b.getLowerBound()) ? b.getLowerBound() : a.getLowerBound());
    	  	  c.setUpperBound((a.getUpperBound() < b.getUpperBound()) ? a.getUpperBound() : b.getUpperBound());
    	  }
    	  ArrayList<Column> temp = a.getAttributes();
    	  for(Column bAttr: b.getAttributes())
    	  {
    		  if(temp.contains(bAttr) == false)
    		  {
    			  temp.add(bAttr);
    		  }
    	  }
    	  c.setAttributes(temp);
    	  unionList.add(c);
    	  
      }
      
     
     
}

package project2DB;

import java.util.ArrayList;
import java.util.Stack;

import net.sf.jsqlparser.expression.*;
import net.sf.jsqlparser.expression.operators.*;
import net.sf.jsqlparser.expression.operators.arithmetic.*;
import net.sf.jsqlparser.expression.operators.conditional.*;
import net.sf.jsqlparser.expression.operators.relational.*;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.select.SubSelect;

public class UnionFindVisitor implements ExpressionVisitor {
	private Stack<Integer> handler = new Stack<Integer>();
	private UnionFind union;
	private ArrayList<Expression> rejectedExpressions = new ArrayList<Expression>();
	
	
	public ArrayList<Expression> getRejectedExpressions() {
		return rejectedExpressions;
	}
	public void setRejectedExpressions(ArrayList<Expression> rejectedExpressions) {
		this.rejectedExpressions = rejectedExpressions;
	}
	public UnionFindVisitor(UnionFind elem)
	{
		union = elem;
	}
	public UnionFind getUnion()
	{
		return union;
	}

	public void expressionHandler(BinaryExpression e)
	{
		
	}
	
	@Override
	public void visit(NullValue arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(Function arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(InverseExpression arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(JdbcParameter arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(DoubleValue arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(LongValue arg0) {
		handler.push((int)arg0.getValue());
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(DateValue arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(TimeValue arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(TimestampValue arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(Parenthesis arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(StringValue arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(Addition arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(Division arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(Multiplication arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(Subtraction arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(AndExpression arg0) {
		// TODO Auto-generated method stub
		arg0.getLeftExpression().accept(this);
		arg0.getRightExpression().accept(this);
		
	}

	@Override
	public void visit(OrExpression arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(Between arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(EqualsTo arg0) {
		   Expression left = arg0.getLeftExpression();
	       Expression right = arg0.getRightExpression();
	       left.accept(this);
	       right.accept(this);
	       int popRight = handler.pop();
	       int popLeft = handler.pop();
	       if(popRight==-1 && popLeft == -1){
	        union.union(union.find((Column)left), union.find((Column)right));
	    	  
	       }
	       else if(popRight ==-1 && popLeft !=-1){
	    	      union.find((Column)right).setEqual(popLeft);
	       }
	       else if(popRight !=-1 && popLeft ==-1)
	       {
	    	      union.find((Column)left).setEqual(popRight);

	       }
		
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public void visit(GreaterThan arg0) {
		   Expression left = arg0.getLeftExpression();
	       Expression right = arg0.getRightExpression();
	       left.accept(this);
	       right.accept(this);
	       int popRight = handler.pop();
	       int popLeft = handler.pop();
	       if(popRight==-1 && popLeft != -1){
	        union.find((Column)right).setUpperBound(popLeft-1);
	    	  
	       }
	       else if(popRight !=-1 && popLeft ==-1){
	    	    union.find((Column)left).setLowerBound(popRight+1	);
	       }
	       else if(popRight == 1 && popLeft == 1)
	       {
	    	   rejectedExpressions.add(arg0);
	       }
		
	}

	@Override
	public void visit(GreaterThanEquals arg0) {
		// TODO Auto-generated method stub
       Expression left = arg0.getLeftExpression();
       Expression right = arg0.getRightExpression();
       left.accept(this);
       right.accept(this);
       int popRight = handler.pop();
       int popLeft = handler.pop();
       if(popRight==-1 && popLeft != -1){
        union.find((Column)right).setUpperBound(popLeft);
    	  
       }
       else if(popRight !=-1 && popLeft ==-1){
    	    union.find((Column)left).setLowerBound(popRight);
       }
       else if(popRight == 1 && popLeft == 1)
       {
    	   rejectedExpressions.add(arg0);
       }
       
	}

	@Override
	public void visit(InExpression arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(IsNullExpression arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(LikeExpression arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(MinorThan arg0) {
		   Expression left = arg0.getLeftExpression();
	       Expression right = arg0.getRightExpression();
	       left.accept(this);
	       right.accept(this);
	       int popRight = handler.pop();
	       int popLeft = handler.pop();
	       if(popRight==-1 && popLeft != -1){
	        union.find((Column)right).setLowerBound(popLeft+1);
	    	  
	       }
	       else if(popRight !=-1 && popLeft ==-1){
	    	    union.find((Column)left).setUpperBound(popRight-1);
	       }
	       else if(popRight == 1 && popLeft == 1)
	       {
	    	   rejectedExpressions.add(arg0);
	       }
	}

	@Override
	public void visit(MinorThanEquals arg0) {
		   Expression left = arg0.getLeftExpression();
	       Expression right = arg0.getRightExpression();
	       left.accept(this);
	       right.accept(this);
	       int popRight = handler.pop();
	       int popLeft = handler.pop();
	       if(popRight==-1 && popLeft != -1){
	        union.find((Column)right).setLowerBound(popLeft);
	    	  
	       }
	       else if(popRight !=-1 && popLeft ==-1){
	    	    union.find((Column)left).setUpperBound(popRight);
	       }
	       else if(popRight == 1 && popLeft == 1)
	       {
	    	   rejectedExpressions.add(arg0);
	       }

		
	}

	@Override
	public void visit(NotEqualsTo arg0) {
		rejectedExpressions.add(arg0);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(Column arg0) {
		handler.push(-1);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(SubSelect arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(CaseExpression arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(WhenClause arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(ExistsExpression arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(AllComparisonExpression arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(AnyComparisonExpression arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(Concat arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(Matches arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(BitwiseAnd arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(BitwiseOr arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void visit(BitwiseXor arg0) {
		// TODO Auto-generated method stub
		
	}

}

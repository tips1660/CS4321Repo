package logicalOperators;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import net.sf.jsqlparser.expression.BinaryExpression;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.LongValue;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
import net.sf.jsqlparser.expression.operators.relational.GreaterThanEquals;
import net.sf.jsqlparser.expression.operators.relational.MinorThanEquals;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.select.Join;
import net.sf.jsqlparser.statement.select.SelectItem;
import project2DB.UnionFind;
import project2DB.UnionFindElement;

/**
 * JoinOperatorLogical stores all the information needed to create a physical JoinOperator in the PhysicalPlanBuilder
 * @author Pulkit Kashyap pk374 Robert Cao rrc85 Jason Zhou jz629
 */
public class JoinOperatorLogical extends LogicalOperator{

	Table tableN;
    List<Join> jList;
    Expression e;
    ArrayList<SelectItem> items;
	private UnionFind union;
	private ArrayList<Expression> rejected = new ArrayList<Expression>();
    private HashMap<Table, LogicalOperator> children = new HashMap<Table,LogicalOperator>();
    private JoinOperatorBuilder joinBuilder;
    private ArrayList<Table> joinOrder = new ArrayList<Table>();
    /**
	 * Gets the table of the base relation
	 * @return tableN
	 */
	public Table getTableN() {
		return tableN;
	}
	
	/**
	 * Sets the table of the base relation
	 * @param tableN
	 */
	public void setTableN(Table tableN) {
		this.tableN = tableN;
	}
	
	/**
	 * Get the list of joins
	 * @return jList
	 */
	public List<Join> getjList() {
		return jList;
	}
	
	/**
	 * Sets the list of joins
	 * @param jList
	 */
	public void setjList(List<Join> jList) {
		this.jList = jList;
	}
	
	/**
	 * Get the expression of the query
	 * @return e
	 */
	public Expression getE() {
		return e;
	}
	
	/**
	 * Set the expression of the query
	 * @param e
	 */
	public void setE(Expression e) {
		this.e = e;
	}
	
	/**
	 * Set the select items 
	 * @param items1
	 */
	public void setItems(ArrayList<SelectItem> items1) {
		items = items1;
		
	}
	
	/**
	 * Get the select items 
	 * @return
	 */
	public ArrayList<SelectItem> getItems()
	{
		return items;
	}
	
	/**
	 * Method for visiting this operator in a physical plan builder
	 * @param s
	 */
	@Override
	public void accept(PhysicalPlanBuilder s) throws IOException {
         s.visit(this);		
	}

	public void setUnionFind(UnionFind union) {
		// TODO Auto-generated method stub
		this.union = union;
		rejected = union.getRejectedExp();
		
	}
	
	public void generateChildren()
	{
		ArrayList<Table> tbl = new ArrayList<Table>();
		tbl.add(tableN);
		for(Join a: jList)
		{
			tbl.add(((Table)a.getRightItem()));
		}
		joinBuilder = new JoinOperatorBuilder(tbl, union);
		joinBuilder.buildJoinOrder();
		joinOrder = joinBuilder.getJoinOrder();
		setTableN(joinOrder.remove(0));
		List<Join> newJoinList = new ArrayList<Join>();
		for (int i = 0; i < joinOrder.size(); i++)
		{
			Join j = new Join();
			j.setRightItem(joinOrder.get(i));
			newJoinList.add(j);
		}
		setjList(newJoinList);
		
		ArrayList<BinaryExpression> exp = new ArrayList<BinaryExpression>();
		ArrayList<Column> sameCol = new ArrayList<Column>();
		Expression finalExp = null;
		for (Table t: tbl) {
			for (UnionFindElement u: union.getUnionList()) {
				for (Column c: u.getAttributes()) {
					if (c.getTable().equals(t)) {
						sameCol.add(c);
						if (u.getEqual() != null) {
							BinaryExpression eq = new EqualsTo();
							eq.setLeftExpression(c);
							eq.setRightExpression(new LongValue(u.getEqual()));
							exp.add(eq);
						}
						else {
							if (u.getLowerBound() > 0) {
								BinaryExpression great = new GreaterThanEquals();
								great.setLeftExpression(c);
								great.setRightExpression(new LongValue(u.getLowerBound()));
								exp.add(great);
							}
							if (u.getUpperBound() < Integer.MAX_VALUE) {
								BinaryExpression less = new GreaterThanEquals();
								less.setLeftExpression(c);
								less.setRightExpression(new LongValue(u.getUpperBound()));
								exp.add(less);
							}
						}
					}
				}
				if (sameCol.size() > 1) {
					Column c1 = sameCol.get(0);
					for (int i = 1; i < sameCol.size(); i++) {
						BinaryExpression eq = new EqualsTo();
						eq.setLeftExpression(c1);
						eq.setRightExpression(sameCol.get(i));
						exp.add(eq);
					}
				}
			}
			int ctr =0; 
			ArrayList<Expression> subtract = new ArrayList<Expression>();
			while(rejected.get(ctr) !=null) {
				Expression e1 = rejected.get(ctr);
				BinaryExpression e = (BinaryExpression) e1;
				if (!(e.getLeftExpression() instanceof Column && e.getRightExpression() instanceof Column)) {
					if (((Column) e.getLeftExpression()).getTable().equals(t) || ((Column) e.getRightExpression()).getTable().equals(t)) {
							exp.add(e);
							subtract.add(e1);
							rejected.remove(e1);
							
					}
					else
					{
						ctr++;
					}
				}
			
			}
			
			if (exp.isEmpty()) {
				ScanOperatorLogical curLogical = new ScanOperatorLogical(t);
				children.put(t, curLogical);
			}
			else {
				if (exp.size() == 1) {
					//expression is a single
					finalExp = exp.get(0);
				}
				else {
					finalExp = new AndExpression();
					((BinaryExpression) finalExp).setLeftExpression(exp.get(0));
					((BinaryExpression) finalExp).setRightExpression(exp.get(1));
					for (int i = 2; i < exp.size(); i++) {
						((BinaryExpression) finalExp).setLeftExpression(finalExp);
						((BinaryExpression) finalExp).setRightExpression(exp.get(i));
					}
				}
				//build select operator child here
				SelectOperatorLogical curLogical = new SelectOperatorLogical();
				curLogical.setInput(finalExp);
				curLogical.setTableN(t);
				curLogical.setChild(new ScanOperatorLogical(t));
				children.put(t, curLogical);
			}
			exp.clear();
			sameCol.clear();
			
		}
		
	 // base d off the unionfind make a bunch of select operator logcials
	}
	


}

package logicalOperators;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Hashtable;

import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
import project2DB.DatabaseCatalog;
import project2DB.Stats;
import project2DB.UnionFind;
import project2DB.UnionFindElement;
import project2DB.tableProperties;

public class JoinOperatorBuilder {

	private DatabaseCatalog dbcat = DatabaseCatalog.getInstance();
	private ArrayList<Table> tables = new ArrayList<Table>();
	private HashMap<ArrayList<Table>, VValues> vvalues = new HashMap<ArrayList<Table>, VValues>();
	private UnionFind u;
	private HashMap<String, Stats> st = new HashMap<String, Stats>(dbcat.getColumnToStats());
	private Hashtable<String, tableProperties> tblProperties = dbcat.getTableCatalog();
	private HashMap<ArrayList<Table>, Integer> costs = new HashMap<ArrayList<Table>, Integer>();
	private HashMap<ArrayList<Table>, ArrayList<Table>> joinOrder = new HashMap<ArrayList<Table>, ArrayList<Table>>();
	private HashMap<ArrayList<Table>, Integer> sizes = new HashMap<ArrayList<Table>, Integer>();
	
	private HashMap<Integer, ArrayList<ArrayList<Table>>> subsets = new HashMap<Integer, ArrayList<ArrayList<Table>>>();
	private HashMap<Column, Double> reductionFactors = new HashMap<Column, Double>();
	
	public JoinOperatorBuilder(ArrayList<Table> t, UnionFind union)
	{
		tables = t;
		u = union;
	}
	
	public void buildJoinOrder()
	{
		pass1();
		pass2();
		for (int i = 2; i < tables.size(); i++)
		{
			passk(i, subsets.get(i));
		}
	}
	
	public ArrayList<Table> getJoinOrder()
	{
		Collections.sort(tables, TableComparator);
		return joinOrder.get(tables);
	}
	
	public void calculateVValues()
	{
		Hashtable<String, tableProperties> tblProperties = dbcat.getTableCatalog();
		ArrayList<String> cols = new ArrayList<String>();
		
		Collections.sort(tables, TableComparator);
		for (Table tbl: tables) {
			int size = st.get(cols.get(0)).getNumTuples();
			String tName = tbl.getName();
			tableProperties tp = tblProperties.get(tName);
			cols = tp.getColumns();
			Hashtable<Column, Integer> values = new Hashtable<Column, Integer>();
			for (int i = 0; i < cols.size(); i++) {
				Stats columnStats = st.get(cols.get(i));
				Column c = new Column(tbl, cols.get(i));
				values.put(c, columnStats.getMax() - columnStats.getMin() + 1);
				size = (int) (size * reductionFactors.get(c));
			}
			ArrayList<Table> startingTbl = new ArrayList<Table>();
			startingTbl.add(tbl);
			VValues startValue = new VValues(startingTbl, values);
			vvalues.put(startingTbl, startValue);
			costs.put(startingTbl, 0);
			joinOrder.put(startingTbl, startingTbl);
			sizes.put(startingTbl,size);
			//reduce size possibly
		}
	}
	
	public void pass1()
	{
		for (UnionFindElement a: u.getUnionList()) {
			int max = a.getUpperBound();
			int min = a.getLowerBound();
			for (Column c: a.getAttributes()) {
				int oldMax = st.get(c.getColumnName()).getMax();
				int oldMin = st.get(c.getColumnName()).getMin();
				int oldRange = oldMax - oldMin;
				if (st.get(c.getColumnName()).getMax() > max) {
					st.get(c.getColumnName()).setMax(max);
					oldMax = max;
				}
				if (st.get(c.getColumnName()).getMin() < min) {
					st.get(c.getColumnName()).setMin(min);
					oldMin = min;
				}
				double range = ((double)(oldMax - oldMin))/oldRange;
				reductionFactors.put(c, range);
			}
		}
		calculateVValues();
	}
	
	public void pass2()
	{
		//need to handle self joins
		ArrayList<ArrayList<Table>> ksubset = new ArrayList<ArrayList<Table>>();
		for (int i = 0; i < tables.size()-1; i++) {
			for (int j = i+1; j < tables.size(); j++) {
					//calculate the join of tables i and j
				boolean crossProduct = true;
				ArrayList<Table> s = new ArrayList<Table>();
				s.add(tables.get(i));
				s.add(tables.get(j));
				Collections.sort(s, TableComparator);
				if (!ksubset.contains(s))
					ksubset.add(s);
				ArrayList<Table> lTbl = new ArrayList<Table>();
				lTbl.add(tables.get(i));
				ArrayList<Table> rTbl = new ArrayList<Table>();
				rTbl.add(tables.get(j));
				for (UnionFindElement a: u.getUnionList())
				{
					for (int x = 0; x < a.getAttributes().size()-1; x++)
					{
						if (tables.get(i).equals(a.getAttributes().get(x).getTable()))
						{
							for (int y = x+1; y < a.getAttributes().size(); y++)
							{
								if (tables.get(j).equals(a.getAttributes().get(y).getTable()))
								{
									Column left = a.getAttributes().get(x);
									Column right = a.getAttributes().get(y);
									calculateJoinVValues(lTbl, tables.get(j), left, right);
									costs.put(s, 0);
									crossProduct = false;
								}
							}
						}
					}
				}
				if (crossProduct)
				{
					int size = sizes.get(lTbl)*sizes.get(lTbl);
					sizes.put(s, size);
					
				}
				costs.put(s, 0);
				if (sizes.get(lTbl) < sizes.get(rTbl))
				{
					//Smaller relation should be outer. 
					joinOrder.put(s,s);
				}
				else
				{
					ArrayList<Table> newOrder = new ArrayList<Table>(s);
					Collections.reverse(newOrder);
					joinOrder.put(s, newOrder);
				}
			}
		}
		subsets.put(2, ksubset);
	}
	
	public void passk(int passNumber, ArrayList<ArrayList<Table>> subset)
	{
		ArrayList<ArrayList<Table>> ksubset = new ArrayList<ArrayList<Table>>();
		for (int i = 0; i < subset.size(); i++)
		{
			for (int j = 0; j < tables.size(); j++)
			{
				ArrayList<Table> s = new ArrayList<Table>(subset.get(i));
				s.add(tables.get(j));
				Collections.sort(s, TableComparator);
				if (!ksubset.contains(s))
					ksubset.add(s);
				if (!subset.get(i).contains(tables.get(j)))
				{
					boolean crossProduct = true;
					//use union find to get shit 
					for (UnionFindElement a: u.getUnionList())
					{
						for (int x = 0; x < a.getAttributes().size()-1; x++)
						{
							if (subset.get(i).contains(a.getAttributes().get(x).getTable()))
							{
								for (int y = x+1; y < a.getAttributes().size(); y++)
								{
									if (tables.get(j).equals(a.getAttributes().get(y).getTable()))
									{
										crossProduct = false;
										Column left = a.getAttributes().get(x);
										Column right = a.getAttributes().get(y);
										calculateJoinVValues(subset.get(i), tables.get(j), left, right);
									}
								}
							}
						}
					}
					if (crossProduct)
					{
						ArrayList<Table> cp = new ArrayList<Table>(subset.get(i));
						cp.add(tables.get(j));
						Collections.sort(cp, TableComparator);
						ArrayList<Table> rightTbl = new ArrayList<Table>();
						rightTbl.add(tables.get(j));
						int size = sizes.get(subset.get(i))*sizes.get(rightTbl);
						if (sizes.get(cp) == null || (sizes.get(cp) != null && sizes.get(cp) > size)) {
							sizes.put(cp, size);
							costs.put(cp, costs.get(subset.get(i)) + sizes.get(subset.get(i)));
							ArrayList<Table> joinCP = new ArrayList<Table>();
							joinCP = joinOrder.get(subset.get(i));
							joinCP.add(tables.get(j));
							joinOrder.put(cp, joinCP);
						}
					}
				}
			}
		}
		subsets.put(passNumber, ksubset);
	}
	public void calculateJoinVValues(ArrayList<Table> aList, Table b, Column c, Column d)
	{
		//TODO: if V-value > # tuples, V-value = # tuples
		//if # tuples = 0, V-value = 1
		ArrayList<Table> rightTbl = new ArrayList<Table>();
		rightTbl.add(b);
		
		ArrayList<Table> newList = new ArrayList<Table>(aList);
		newList.add(b);
		Collections.sort(newList,TableComparator);
		
		VValues leftVal = vvalues.get(aList);
		VValues rightVal = vvalues.get(rightTbl);
		int min = Math.min(leftVal.getValues().get(c), rightVal.getValues().get(d));
		
		ArrayList<Table> rTbl = new ArrayList<Table>();
		rTbl.add(b);
		int size;
		if (sizes.get(newList) != null)
			size = sizes.get(newList)/min;
		else
			size = sizes.get(aList)*sizes.get(rTbl)/min;
		if (min > size)
			min = size;

		Hashtable<Column, Integer> newValues = new Hashtable<Column, Integer>();
		ArrayList<String> rightCol = tblProperties.get(b).getColumns();
			
		for (int z = 0; z < aList.size(); z++) {
			ArrayList<String> leftCol = tblProperties.get(aList.get(z)).getColumns();
			for (int x = 0; x < leftCol.size(); x++) {
				Column y = new Column(aList.get(z), leftCol.get(x));
				if (leftCol.get(x).equals(c.getColumnName())) {
					newValues.put(y,min);
				}
				else {
					if (leftVal.getValues().get(y) > size)
						newValues.put(y, size);
					else
						newValues.put(y, leftVal.getValues().get(y));
				}
			}
		}
		for (int x = 0; x < rightCol.size(); x++) {
			Column y = new Column(b, rightCol.get(x));
			if (rightCol.get(x).equals(d.getColumnName())) {
				newValues.put(y,min);
			}
			else {
				if (rightVal.getValues().get(y) > size)
					newValues.put(y, size);
				else
					newValues.put(y, rightVal.getValues().get(y));
			}
		}
		
		VValues newVValues = new VValues(newList, newValues);
		vvalues.put(newList,newVValues);

		int cost = costs.get(aList) + sizes.get(aList);
		ArrayList<Table> newOrder = new ArrayList<Table>(aList);
		newOrder.add(b);
		if (costs.get(newList) != null && cost < costs.get(newList))
		{
			costs.put(newList, cost);
			joinOrder.put(newList,newOrder);
		}
		else if (joinOrder.get(newList) == null)
		{
			joinOrder.put(newList, newOrder);
		}
		sizes.put(newList, size);
	}
	
	public static Comparator<Table> TableComparator = new Comparator<Table>()
	{
		@Override
		/**
		 * Compares two tables
		 * 
		 * @param o1, o2 
		 * Tables
		 * @return value
		 * -1 if o1 < o2, 1 if o1 > o2, 0 if o1 = o2
		 */
		public int compare(Table t1, Table t2) {
			return t1.getName().compareTo(t2.getName());
		}
	};
}

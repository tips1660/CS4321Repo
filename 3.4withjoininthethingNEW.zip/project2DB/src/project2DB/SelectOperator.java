package project2DB;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.schema.Table;


/**
 * ScanOperator is the class representing the Select Operator
 * 
 * @author Robert Cao rrc8 Pulkit Kashyap pk374 Jason Zhou jz629
 */
public class SelectOperator extends Operator {

	public String table = "";
	private DatabaseCatalog dbcat = DatabaseCatalog.getInstance();
	String fileUrl = "";
	Scanner scan;
	Tuple returnedTuple;
	Tuple returnedTuple2;
	Expression e;
	Table t;
	tableProperties tableR;
	ExpressionTester visitor = new ExpressionTester();
	int ctr =0;
	public SelectOperator(Table tableN, Expression input) throws FileNotFoundException
	{  
		//System.out.println("exp passed into select is : "+ tableN.toString());
		t = tableN;
		table = tableN.getWholeTableName();
		tableR = (tableProperties) dbcat.getTableCatalog().get(table);
		fileUrl = tableR.getUrl();
		e=input;
		File f = new File(fileUrl);
		scan = new Scanner(f);
	}
	

	public SelectOperator(Expression input)
	{
		e = input;
	}

	/**
	 * Gets the next tuple from this operator
	 * @return returnedTuple
	 */
	@Override
	public Tuple getNextTuple() {
		//System.out.println("where am i going");
		if(child ==null)
			child = new scanOperator(t);
		returnedTuple = child.getNextTuple();
		//TODO added this for join
		while (returnedTuple == null) {
			returnedTuple = child.getNextTuple();
			//System.out.println("shouldn't be here");
		}
		if(returnedTuple.getTable().equals("ENDOFFILE"))
		{
			//System.out.println("something is very wrong");
			return returnedTuple;
		}
		else{
			//System.out.println("i should end up in here");
			visitor.setTuple(returnedTuple);
			e.accept(visitor);
			
			if(visitor.getResult()==true)
			{
				//System.out.println("do i get to here?");
				return returnedTuple;

			}
			else
			{ 
				//System.out.println("nah shouldnt get to this");
				return null;
			}
		}
	}


	/**
	 * Returns the result of the current tuple when evaluated by an expression
	 * 
	 * @returns visitor.getResult()
	 */
	public boolean getResult()
	{
		return visitor.getResult();
	}
	
	/**
	 * Dump prints out every tuple from the scan
	 */
	@Override
	public void dump() {
		int ctr = 0;
		returnedTuple2 = getNextTuple();

		while(ctr!=6)
		{  
			if(returnedTuple2 !=null)
			{
				for(int i =0; i <returnedTuple2.getValues().size(); i++)
				{
					//System.out.print(returnedTuple2.getValues().get(tableR.getColumns().get(i)) + ", ");
				}
				//System.out.println();
				returnedTuple2 = getNextTuple();
			}
			else
			{
				ctr++;
				returnedTuple2 = getNextTuple();


			}


		}

	}

	/**
	 * Resets this operator such that getNextTuple() will return the first tuple it originally would.
	 */
	@Override
	public void reset() {
		child.reset();
	}
	
	/**
	 * Resets this operator to the tuple at index
	 * @param index
	 */
	@Override
	public void reset(int index) {
		// TODO Auto-generated method stub
		
	}
}